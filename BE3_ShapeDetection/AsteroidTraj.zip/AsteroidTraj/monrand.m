function y = monrand(T)

y = T * (rand-0.5) ;