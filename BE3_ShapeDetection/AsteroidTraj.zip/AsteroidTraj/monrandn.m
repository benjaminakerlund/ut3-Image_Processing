function y = monrandn(taille,T)

y = T * (rand(1,taille)-0.5) ;